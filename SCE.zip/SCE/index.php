<?php 
    include './controllers/C_index.php';
    $mvc = new Index();
    $mvc->base();
?>