<?php
    class Index{
        public function base(){
            require_once './views/base.php';
        }
    }
?>