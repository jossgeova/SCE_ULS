<?php
@session_start();
if (isset($_SESSION['login_ok'])) {
} else {
    header('Location: ../../index.php');
}
include '../../models/conexion.php';
include '../../models/funciones.php';
include '../../controllers/funciones.php';


$tabla = "ubicaciones";
$idubicacion = $_POST['idubicacion'];
$ubicacion = $_POST['ubicacion'];
$estado = $_POST['estado'];

$campos = "ubicacion='$ubicacion',estado='$estado'";
$condicion = "idubicacion='$idubicacion'";

$update = CRUD("UPDATE $tabla SET $campos WHERE $condicion", "u");
if ($update) {
    header("Location: principal.php?msj=" . base64_encode("Ubicación actualizada....."));
    // Asegurarse de que no se siga ejecutando el script
    exit();
} else {
    header("Location: formUpdate.php?idubicacion=" . base64_encode($idubicacion) . "&msj=" . base64_encode("Error al actualizar ubicación...."));
    // Asegurarse de que no se siga ejecutando el script
    exit();
}
