<?php
@session_start();
if (isset($_SESSION['login_ok'])) {
} else {
    header('Location: ../../index.php');
}
include '../../models/conexion.php';
include '../../models/funciones.php';
include '../../controllers/funciones.php';
$idusuario = $_POST['idusuario'];
$tabla = "usuarios";
$condicion = "idusuario='$idusuario'";
$delete = CRUD("DELETE FROM $tabla WHERE $condicion", "d");
if ($delete) {
    header("Location: principal.php?msj=" . base64_encode("Usuario eliminado....."));
    // Asegurarse de que no se siga ejecutando el script
    exit();
} else {
    header("Location: principal.php?msj=" . base64_encode("Error al eliminar usuario....."));
    // Asegurarse de que no se siga ejecutando el script
    exit();
}
