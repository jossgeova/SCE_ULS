<?php
@session_start();
if (isset($_SESSION['login_ok'])) {
} else {
    header('Location: ../../index.php');
}
include '../../models/conexion.php';
include '../../models/funciones.php';
include '../../controllers/funciones.php';
if (isset($_POST['idusuario'])) {
    $idusuario = $_POST['idusuario'];
} else {
    $idusuario = base64_decode($_GET['idusuario']);
}
if(isset($_GET['msj'])){
    $msj = base64_decode($_GET['msj']);
}

$dataUsuario = CRUD("SELECT * FROM usuarios WHERE idusuario='$idusuario'", "s");
foreach ($dataUsuario as $result) {
    $usuario = $result['usuario'];
    $estado = $result['estado'];
    $tipo = $result['tipo'];
}
$vestado = ($estado == 1) ? 'Activo' : 'Desactivo';
$vtipo = ($tipo == 1) ? 'Administrador' : 'Operador';
?>
<!DOCTYPE html>
<html lang="es">
<?php include '../head.php'; ?>

<body>

    <div id="principal" class="container-fluid">
        <?php
        include '../navbar_modulos.php';
        ?>
        <div class="card" style="margin-top:5px; margin-bottom: 5px;">
            <div class="card-header">
                <b>Panel Usuarios (Actualizar)</b> <b style="float:right;">Bienvenido/a</b>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-4">
                        <a href="./principal.php" class="btn btnModulosPrincipal"><b><i class="fa-solid fa-circle-left"></i> Regresar</b></a>
                        <form action="update.php" method="POST">
                            <input type="hidden" name="idusuario" value="<?php echo $idusuario; ?>">
                            <div class="input-group mb-3">
                                <span class="input-group-text" id="basic-addon1">
                                    <b>Usuario: </b>
                                </span>
                                <input type="text" class="form-control" placeholder="Usuario" name="usuario" required value="<?php echo $usuario; ?>">
                            </div>
                            <div class="input-group mb-3">
                                <span class="input-group-text" id="basic-addon1">
                                    <b>Clave: </b>
                                </span>
                                <input type="text" class="form-control" placeholder="Usuario" name="clave">
                            </div>
                            <div class="input-group mb-3">
                                <label class="input-group-text" for="inputGroupSelect01"><b>Tipo</b>: </label>
                                <select class="form-select" id="tipo" name="tipo">
                                    <option value="<?php echo $tipo; ?>" selected><?php echo $vtipo; ?></option>
                                    <?php if ($tipo == 1): ?>
                                        <option value="2">Operador</option>
                                    <?php else: ?>
                                        <option value="1">Administrador</option>
                                    <?php endif ?>
                                </select>
                            </div>
                            <div class="input-group mb-3">
                                <label class="input-group-text" for="inputGroupSelect01"><b>Estado</b>: </label>
                                <select class="form-select" id="estado" name="estado">
                                    <option value="<?php echo $estado; ?>" selected><?php echo $vestado; ?></option>
                                    <?php if ($estado == 1): ?>
                                        <option value="2">Desactivar</option>
                                    <?php else: ?>
                                        <option value="1">Activar</option>
                                    <?php endif ?>
                                </select>
                            </div>
                            <button class=" btn btnModulosPrincipal btn-sm">
                                <b>Actualizar <i class="fa-solid fa-rotate"></i></b>
                            </button>
                        </form>
                    </div>
                    <div class="col-md-4"></div>
                </div>
            </div>
        </div>
    </div>
    <?php include '../../views/modals/modulos.php'; ?>
    <script>
        <?php if (isset($msj)): ?>
            alertify.alert("Actualizar Usuario", "<?php echo $msj; ?>");
            setTimeout(function() {
                // Redirigir a la página de destino
                window.location.href = "formUpdate.php?idusuario=<?php echo base64_encode($idusuario); ?>";
            }, 1000); // 1000 milisegundos = 1 segundo
        <?php endif ?>
    </script>
</body>

</html>